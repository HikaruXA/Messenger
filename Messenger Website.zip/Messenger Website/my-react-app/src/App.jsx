// App.jsx
import React, { useState } from 'react';
import Navbar from "./Navbar";
import Contact from "./pages/Contact";
import Home from "./pages/Login";
import About from "./pages/About";
import Login from "./pages/Login";
import Register from "./pages/Register";
import MessageForm from './messenger/MessageForm';
import GroupMessageForm from './messenger/GroupMessageForm';
import ProfileForm from './profile/ProfileForm';
import UpdateProfileForm from './profile/UpdateProfileForm';
import SearchProfileForm from './profile/SearchProfileForm';
import { Route, Routes, Navigate } from "react-router-dom";
import CreateGroupForm from './messenger/CreateGroupForm';
import Weather from './pages/Weather'; // Import Weather component
import News from './pages/News';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [senderContactNo, setSenderContactNo] = useState('');

  // Function to handle user logout
  const handleLogout = () => {
    setIsLoggedIn(false);
    setSenderContactNo('');
  };

  return (
    <>
      <Navbar isLoggedIn={isLoggedIn} onLogout={handleLogout} />
      {/* Conditionally render Weather component only when isLoggedIn is true */}
      {isLoggedIn && <News />} 
      {isLoggedIn && <Weather />}
     
      <div className="container">
        <Routes>
          {/* Pass setIsLoggedIn to Home component */}
          <Route path="/" element={<Home setIsLoggedIn={setIsLoggedIn} setSenderContactNo={setSenderContactNo} />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/about" element={<About />} />

          {/* Pass setIsLoggedIn to Login component */}
          <Route path="/login" element={<Login setIsLoggedIn={setIsLoggedIn} setSenderContactNo={setSenderContactNo} />} />
          <Route path="/register" element={<Register />} />
          {/* Protect MessageForm route */}
          <Route path="/message-form" element={isLoggedIn ? <MessageForm senderContactNo={senderContactNo} /> : <Navigate to="/login" />} />
          <Route path="/group-message-form" element={isLoggedIn ? <GroupMessageForm senderContactNo={senderContactNo} /> : <Navigate to="/login" />} />
          <Route path="/create-group-form" element={isLoggedIn ? <CreateGroupForm senderContactNo={senderContactNo} /> : <Navigate to="/login" />} />
          <Route path="/profile-form" element={isLoggedIn ? <ProfileForm senderContactNo={senderContactNo} /> : <Navigate to="/login" />} />
          <Route path="/update-form" element={isLoggedIn ? <UpdateProfileForm senderContactNo={senderContactNo} /> : <Navigate to="/login" />} />
          <Route path="/search-form" element={isLoggedIn ? <SearchProfileForm senderContactNo={senderContactNo} /> : <Navigate to="/login" />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </>
  )
}

export default App;
