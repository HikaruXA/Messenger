import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './SearchProfileForm.css';
import { Link } from 'react-router-dom';

const SearchProfileForm = () => {
    const [contactNo, setContactNo] = useState('');
    const [profileData, setProfileData] = useState({
        name: '',
        status: '',
        bio: '',
        profilePicture: ''
    });
    const [error, setError] = useState('');

    const handleChange = (e) => {
        setContactNo(e.target.value);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const userIdResponse = await axios.get(`http://localhost/RMI/PHP/getUserId.php?contactNo=${contactNo}`);
            const userId = userIdResponse.data.id;

            const userResponse = await axios.get(`http://localhost/RMI/PHP/getUser.php?id=${userId}`);
            const name = userResponse.data.name;

            const userProfileResponse = await axios.get(`http://localhost/RMI/PHP/getUserProfile.php?userId=${userId}`);
            const userProfileData = userProfileResponse.data;

            const newStatus = userProfileData.status;
            const newBio = userProfileData.bio;
            const newProfileName = userProfileData.profile_name;

            const profilePicture = `http://localhost/RMI/profile_uploads/${newProfileName}`;

            setProfileData({
                name,
                status: newStatus,
                bio: newBio,
                profilePicture
            });
            setError('');
        } catch (error) {
            setError('Profile not found');
            console.error("Error fetching data:", error);
        }
    };

    return (
        <div className="search-form-container"> {/* Wrap the form within the container */}
            <div className="search-form">
                <form onSubmit={handleSubmit}>
                    <input type="text" value={contactNo} onChange={handleChange} placeholder="Enter Contact Number" required />
                    <button type="submit">Search</button>
                </form>
                {error && <p className="error-message">{error}</p>}
                {profileData.name && (
                    <div className="profile-details">
                        <img src={profileData.profilePicture} alt="Profile" />
                        <h2>{profileData.name}</h2>
                        <p>Status: {profileData.status}</p>
                        <p>Bio: {profileData.bio}</p>
                       
                    </div>
                )}
            </div>
        </div>
    );
};

export default SearchProfileForm;
