import React, { useState, useEffect } from 'react';
import './UpdateProfileForm.css';
import axios from 'axios';

const UpdateProfileForm = ({ senderContactNo }) => {
    const [userId, setUserId] = useState('');
    const [status, setStatus] = useState('');
    const [bio, setBio] = useState('');
    const [selectedFile, setSelectedFile] = useState(null);
    const [imageUrl, setImageUrl] = useState('');

    useEffect(() => {
        const fetchUserId = async () => {
            try {
                const response = await axios.get(`http://localhost/RMI/PHP/getUserId.php?contactNo=${senderContactNo}`);
                const data = response.data;
                if (data && data.id) {
                    setUserId(data.id);
                } else {
                    console.error('Failed to fetch user ID');
                }
            } catch (error) {
                console.error('Error fetching user ID:', error);
            }
        };

        fetchUserId();
    }, [senderContactNo]);

    const handleStatusChange = (e) => {
        setStatus(e.target.value);
    };

    const handleBioChange = (e) => {
        setBio(e.target.value);
    };

    const handleFileChange = (e) => {
        const file = e.target.files[0];
        setSelectedFile(file);
        const url = URL.createObjectURL(file);
        setImageUrl(url);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const formData = new FormData();
            formData.append('userId', userId);
            formData.append('status', status);
            formData.append('bio', bio);
            if (selectedFile) {
                formData.append('profilePicture', selectedFile);
            }

            const response = await axios.post('http://localhost/RMI/PHP/updateUserProfile.php', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });

            console.log('Profile updated successfully:', response.data);
            // Reset form fields
            setStatus('');
            setBio('');
            setSelectedFile(null);
            setImageUrl('');
        } catch (error) {
            console.error('Error updating profile:', error);
        }
    };

    return (
        <>
            <div className='background-profile-container'>
                <div className="profile-container">
                    <center>
                    <div className='circle-container'>
                        {imageUrl && <img src={imageUrl} alt="Profile" className="profile-image" />}
                    </div>
                    </center>
                    <form onSubmit={handleSubmit}>
                        <label htmlFor="profilePicture">Profile Picture:</label>
                        <br />
                        <input type="file" id="profilePicture" onChange={handleFileChange} />
                        <br />
                        <label htmlFor="status">Status:</label>
                        <select id="status" value={status} onChange={handleStatusChange}>
                            <option value="Active">Active</option>
                            <option value="Offline">Offline</option>
                            <option value="Working">Working</option>
                        </select>
                        <br />
                        <label htmlFor="bio">Bio:</label>
                        <textarea id="bio" value={bio} onChange={handleBioChange}></textarea>
                        <br />
                        <button type="submit">Update Profile</button>
                    </form>
                </div>
            </div>
        </>
    );
};

export default UpdateProfileForm;
