import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './ProfileForm.css'
import { Link } from 'react-router-dom';

const ProfileForm = ({ senderContactNo }) => {
    const [profileData, setProfileData] = useState({
        name: '',
        status: '',
        bio: '',
        profilePicture: ''
    });

    useEffect(() => {
        const fetchData = async () => {
            try {
                const userIdResponse = await axios.get(`http://localhost/RMI/PHP/getUserId.php?contactNo=${senderContactNo}`);
                const userId = userIdResponse.data.id;

                const userResponse = await axios.get(`http://localhost/RMI/PHP/getUser.php?id=${userId}`);
                const name = userResponse.data.name;

                const userProfileResponse = await axios.get(`http://localhost/RMI/PHP/getUserProfile.php?userId=${userId}`);
                const userProfileData = userProfileResponse.data;

                // Log retrieved data to ensure correctness
                console.log("User Profile Data:", userProfileData);

                // Make sure userProfileData contains the expected fields (status, bio, profile_name)
                // Log the fields to verify
                console.log("Status:", userProfileData.status);
                console.log("Bio:", userProfileData.bio);
                console.log("Profile Name:", userProfileData.profile_name);

                const newStatus = userProfileData.status;
                const newBio = userProfileData.bio;
                const newProfileName = userProfileData.profile_name;

                // Ensure that the profile name is being retrieved correctly
                console.log("New Profile Name:", newProfileName);

                const profilePicture = `http://localhost/RMI/profile_uploads/${newProfileName}`;

                setProfileData({
                    name,
                    status: newStatus,
                    bio: newBio,
                    profilePicture
                });
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        };

        fetchData();
    }, [senderContactNo]);

    useEffect(() => {
        console.log("Updated Profile Data:", profileData);
    }, [profileData]);



    return (
        <>
        <div className='profile-background'>
        <div className="profile-container">
            <img src={profileData.profilePicture} alt="Profile" />
            <h2>{profileData.name}</h2>
            <p>Status: {profileData.status}</p>
            <p>Bio: {profileData.bio}</p>
            <Link to="/update-form">
                <button>Update your Profile Information</button>
            </Link>
        </div>

        </div>
       
        </>
    );
};

export default ProfileForm;
