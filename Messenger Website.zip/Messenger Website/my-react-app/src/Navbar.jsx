import React from 'react';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom'; // Import useNavigate hook
import './index.css';

export default function Navbar({ isLoggedIn }) {
  const navigate = useNavigate(); // Hook for navigation

  const handleSignOut = () => {
    // Implement your sign-out logic here
    // For example, clearing local storage, resetting state, etc.

    // Reload the page after sign-out
    window.location.reload();
  };

  return (
    <nav className="nav">
      <h1 className="NavHeader">CipherTalk</h1>
      <ul>
        {/* Conditionally render MessageForm and GroupMessageForm links when logged in */}
        {isLoggedIn ? (
          <>
            <CustomLink to="/profile-form">Profile</CustomLink>
            <CustomLink to="/search-form">Search Profile</CustomLink>
            <CustomLink to="/message-form">Chat</CustomLink>
            <CustomLink to="/create-group-form">Create Group Chat</CustomLink>
           
              <button onClick={handleSignOut}>Sign Out</button>
            
          </>
        ) : (
          <>
            <CustomLink to="/login">Sign In</CustomLink>
            <CustomLink to="/register">Sign Up</CustomLink>
            <CustomLink to="/about">About</CustomLink>
            <CustomLink to="/contact">Contact</CustomLink>
          </>
        )}
      </ul>
    </nav>
  );
}

function CustomLink({ to, children, ...props }) {
  return (
    <li>
      <Link to={to} {...props}>
        {children}
      </Link>
    </li>
  );
}
