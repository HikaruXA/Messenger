import React, { useState, useEffect } from 'react';

const Weather = () => {
  const [weather, setWeather] = useState(null);
  const [showNotification, setShowNotification] = useState(true);
  const [suggestion, setSuggestion] = useState('');
  const [backgroundColor, setBackgroundColor] = useState('rgba(240, 240, 240, 0.8)'); // Default background color with some opacity
  const [latitude, setLatitude] = useState(null);
  const [longitude, setLongitude] = useState(null);

  useEffect(() => {
    navigator.geolocation.getCurrentPosition(position => {
      const { latitude, longitude } = position.coords;
      setLatitude(latitude);
      setLongitude(longitude);

      fetch(`http://localhost/RMI/PHP/weather.php?lat=${latitude}&lon=${longitude}`)
        .then(response => response.json())
        .then(data => {
          setWeather(data);
          // Convert temperature to Celsius
          const tempCelsius = kelvinToCelsius(data.main.temp_max);
          // Check weather conditions and set suggestion
          if (tempCelsius >= 30) {
            setSuggestion('It\'s hot outside! Consider wearing light clothes and bringing water.');
            setBackgroundColor('rgba(255, 204, 204, 0.8)'); // Light red for hot with some opacity
          } else if (data.weather[0].main === 'Rain') {
            setSuggestion('It\'s raining! Don\'t forget to bring an umbrella.');
            setBackgroundColor('rgba(204, 230, 255, 0.8)'); // Light blue for rain with some opacity
          } else if (tempCelsius < 30) {
            setSuggestion('It\'s cold outside, bring a sweater.');
            setBackgroundColor('rgba(204, 230, 255, 0.8)'); // Light blue for rain with some opacity
          } else {
            setSuggestion(''); // Reset suggestion if not hot or raining
            setBackgroundColor('rgba(240, 240, 240, 0.8)'); // Default color for other conditions with some opacity
          }
        })
        .catch(error => console.error('Error fetching weather:', error));
    });
  }, [latitude, longitude]);

  const kelvinToCelsius = temp_max => {
    return temp_max - 273.15;
  };

  const toggleNotification = () => {
    setShowNotification(prevState => !prevState);
  };

  return (
    <div>
      {showNotification && (
        <div style={{ position: 'fixed', bottom: 0, left: 0, width: '100%', backgroundColor: backgroundColor, padding: '10px', borderTop: '1px solid #ccc' }}>
          <div>
            <h2>Notification: Weather Information</h2>
            {weather && (
              <div>
                <p>Rain: {weather.weather[0].main}</p>
                <p>Temperature: {kelvinToCelsius(weather.main.temp_max).toFixed(2)}°C</p>
                <p>Humidity: {weather.main.humidity}%</p>
                <p>Wind Speed: {weather.wind.speed} m/s</p>
                {suggestion && <p>Suggestion: {suggestion}</p>}
              </div>
            )}

            <button onClick={toggleNotification} style={{ float: 'right', cursor: 'pointer', backgroundColor: '#007bff', color: '#fff', border: 'none', borderRadius: '5px', padding: '10px 20px', fontSize: '16px' }}>{showNotification ? 'Hide' : 'Show'} Weather</button>
          </div>
        </div>
      )}
      {!showNotification && (
        <button onClick={toggleNotification} style={{ position: 'fixed', bottom: 0, right: 0, margin: '10px', cursor: 'pointer', backgroundColor: '#007bff', color: '#fff', border: 'none', borderRadius: '5px', padding: '10px 20px', fontSize: '16px' }}>Show Weather</button>
      )}
    </div>
  );
};

export default Weather;
