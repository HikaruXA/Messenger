import React, { useState } from 'react';
import axios from 'axios';
import './login.css';
import { useNavigate } from 'react-router-dom'; // Import useNavigate hook

const Login = ({ setIsLoggedIn, setSenderContactNo }) => {
    const [formData, setFormData] = useState({
        contactNo: '',
        password: ''
    });
    const [loginError, setLoginError] = useState(false);
    const navigate = useNavigate(); // Hook for navigation

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const params = new URLSearchParams(formData); // Serialize form data
            const response = await axios.post('http://localhost/RMI/PHP/login.php', params, {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            });
            console.log(response.data);
            // Check if login was successful
            if (response.data.message === 'Login successful') {
                // Handle login success
                setIsLoggedIn(true); // Set isLoggedIn to true
                setSenderContactNo(formData.contactNo); // Set the senderContactNo
                navigate('/message-form'); // Redirect to the message form
            } else {
                // Handle login failure, e.g., display error message
                console.log("Login failed");
                setLoginError(true); // Set loginError to true
            }
        } catch (error) {
            console.error(error);
            // Handle login failure, e.g., display error message
        }
    };

    return (
        <div className="login-page">
            <div className="background-wallpaper">
                <div className='middle-container'>
                    <div className='right-container'>

                        <form onSubmit={handleSubmit}>
                            <h2>Login</h2>
                            {loginError && <p>The contact number or password is wrong</p>}
                            <div className='input-container'>
                                <input type="text" name="contactNo" value={formData.contactNo} onChange={handleChange} placeholder="Contact Number" className={loginError ? 'error' : ''} required />
                            </div>

                            <div className='input-container'>
                                <input type="password" name="password" value={formData.password} onChange={handleChange} placeholder="Password" className={loginError ? 'error' : ''} required />
                            </div>
                            <br />
                            <button type="submit">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Login;
