import React from 'react';
import './About.css';

const About = () => {
    return (
        <div className='about'>
              
            <main className="main-content">
                <div className="about-container">
                    <h1>CipherTalk</h1>
                    <h2>Messaging App Function</h2>
                    <p>The messaging app allows users to send text messages, files, and interact with other users in real-time. It provides features such as:</p>
                    <ul>
                        <li>Creating new group chats</li>
                        <li>Adding and removing members from group chats</li>
                        <li>Sending and receiving text messages</li>
                        <li>Uploading and downloading files</li>
                        <li>Viewing chat history and file history</li>
                        <li>Sorting and filtering recipients</li>
                        <li>Private and public chat modes</li>
                    </ul>
                    <p>The app aims to provide a seamless and intuitive communication experience for users, enhancing collaboration and connectivity among individuals or groups.</p>
                </div>
            </main>
            <footer className="footer">
                <p>&copy; 2024 CipherTalk</p>
            </footer>
        </div>
    );
};

export default About;
