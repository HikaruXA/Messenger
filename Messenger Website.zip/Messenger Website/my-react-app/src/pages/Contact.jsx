import React from 'react';
import Ian from '../images/pfp.jpg';
import MARVIN from '../images/marvin.jpg';
import Rome from '../images/rome.jpg';
import './Contact.css';

export default function Contact() {
  return (
    <>
      <div className='background-contact'>
        <div className="responsive">
          <div className="gallery">
            <a target="_blank" href="https://www.facebook.com/Ic.0716">
              <img src={Ian} alt="Ian" width="350" height="200" />
            </a>
            <div className="desc">
              <p>Name: Ian Clark Cañete</p>
               <p>Email: i.canete.524581@umindanao.edu.ph </p>
            </div>
          </div>
        </div>

        <div className="responsive">
          <div className="gallery">
            <a target="_blank" href="https://www.facebook.com/marvin19.jaganas">
              <img src={MARVIN} alt="Marvin" width="350" height="200" />
            </a>
            <div className="desc">
              <p>Name: Marvin Jaganas</p>
              <p>Email: m.jaganas.527157@umindanao.edu.ph</p>
            </div>
          </div>
        </div>

        <div className="responsive">
          <div className="gallery">
            <a target="_blank" href="https://www.facebook.com/romefrancis.cabangal.58/">
              <img src={Rome} alt="Rome" width="350" height="200" />
            </a>
            <div className="desc">
              <p>Name: Rome Francis Cabangal</p>
              <p>Email: r.cabangal.524231@umindanao.edu.ph</p>
            </div>
          </div>
        </div>

        <div className="clearfix"></div>
      </div>

      <div className="Footer" style={{ padding: '6px', backgroundColor: 'black', color:'white' }}>
      <p>&copy; 2024 CipherTalk</p>
      </div>
    </>
  );
}
