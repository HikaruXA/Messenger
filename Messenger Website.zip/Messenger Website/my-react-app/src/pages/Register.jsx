import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Register.css';

const RegisterForm = () => {
    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        name: '',
        contactNo: '',
        password: '',
        bio: '',
        profilePicture: null
    });

    const [errors, setErrors] = useState({});
    const [registrationStatus, setRegistrationStatus] = useState(null);

    const handleChange = (e) => {
        const { name, value, files } = e.target;

        if (name === 'profilePicture') {
            if (files.length > 0) {
                setFormData(prevState => ({
                    ...prevState,
                    profilePicture: files[0]
                }));
            } else {
                setFormData(prevState => ({
                    ...prevState,
                    profilePicture: '../images/default.png'
                }));
            }
        } else {
            setFormData(prevState => ({
                ...prevState,
                [name]: value
            }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Validate contact number
        if (formData.contactNo.length !== 11) {
            setErrors(prevErrors => ({
                ...prevErrors,
                contactNo: 'Contact number must be 11 digits'
            }));
            return;
        } else {
            setErrors(prevErrors => ({
                ...prevErrors,
                contactNo: ''
            }));
        }

        // Validate password
        if (formData.password.length < 8 || !/[!@#$%^&*]/.test(formData.password)) {
            setErrors(prevErrors => ({
                ...prevErrors,
                password: 'Password must be at least 8 characters long and contain at least one special character'
            }));
            return;
        } else {
            setErrors(prevErrors => ({
                ...prevErrors,
                password: ''
            }));
        }

        try {
            const formDataToSend = new FormData();
            Object.entries(formData).forEach(([key, value]) => {
                formDataToSend.append(key, value);
            });
            const response = await axios.post('http://localhost/RMI/PHP/register.php', formDataToSend, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            setRegistrationStatus(response.data.message);
            navigate('/login');
        } catch (error) {
            console.error(error);
            setRegistrationStatus('Error occurred during registration');
        }
    };


    return (
        <div className="register-page">
            <div className="background-wallpaper">
                <div className='middle-container'>
                    <div className='right-container'>
                        <form onSubmit={handleSubmit}>
                            <h2>Register</h2>
                            {registrationStatus &&
                                <div className="popup-alert">
                                    <p>{registrationStatus}</p>
                                </div>
                            }
                            <center>
                                {formData.profilePicture && formData.profilePicture instanceof File && (
                                    <div className="profile-picture-container">
                                        <img src={URL.createObjectURL(formData.profilePicture)} alt="Profile" className="profile-picture" />
                                    </div>
                                )}
                            </center>
                            <br />
                            <input type="file" name="profilePicture" onChange={handleChange} accept="image/*" />
                            <br />
                            <input type="text" name="name" value={formData.name} onChange={handleChange} placeholder="Name" required />
                            <br />
                            <input type="text" name="contactNo" value={formData.contactNo} onChange={handleChange} placeholder="Contact Number" required />
                            <br />
                            {errors.contactNo && <span className="error">{errors.contactNo}</span>}
                            <br />
                            <input type="password" name="password" value={formData.password} onChange={handleChange} placeholder="Password" required />
                            <br />
                            {errors.password && <span className="error">{errors.password}</span>}
                            <input type="text" name="bio" value={formData.bio} onChange={handleChange} placeholder="Bio" />
                            <br />
                            <button type="submit">Register</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default RegisterForm;
