import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './News.css';

const LatestTeslaNews = () => {
  const [latestNews, setLatestNews] = useState([]);
  const [showNews, setShowNews] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('https://newsapi.org/v2/everything?q=tesla&from=2024-02-03&sortBy=publishedAt&apiKey=49cbca9c61354f3ca8a4b9447d783bb3');
        setLatestNews(response.data.articles);
      } catch (error) {
        console.error('Error fetching news:', error);
      }
    };

    fetchData();
  }, []);

  const toggleNews = () => {
    setShowNews(prevState => !prevState);
  };

  return (
    <div className="news-container">
      {showNews && (
        <div className="latest-news">
          <button onClick={toggleNews} className="toggle-news-button top-right">Hide News</button>
          <div>
            <h2>Latest Tesla News</h2>
            <ul>
              {latestNews.map((article, index) => (
                <><li key={index}>
                      <h3>{article.title}</h3>
                      <p>{article.description}</p>
                      <p>Published at: {article.publishedAt}</p>
                      <p>Source: {article.source.name}</p>
                      <a href={article.url} target="_blank" rel="noopener noreferrer">
                          Read More
                      </a>
                  </li><hr></hr></>
              ))}
            </ul>
          </div>
        </div>
      )}
      {!showNews && (
        <button onClick={toggleNews} className="show-news-button">Show Tesla News</button>
      )}
    </div>
  );
};

export default LatestTeslaNews;
