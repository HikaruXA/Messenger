import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './GroupMessageForm.css';
import personImage from '../images/person.png'; // Import individual image
import groupImage from '../images/group.png'; // Import group image
import { useNavigate } from 'react-router-dom';

const GroupMessageForm = ({ senderContactNo }) => {
  const navigate = useNavigate();
  const [groupNames, setGroupNames] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState('');
  const [message, setMessage] = useState('');
  const [file, setFile] = useState(null);
  const [chatHistory, setChatHistory] = useState([]);
  const [fileHistory, setFileHistory] = useState([]);
  const [currentUserID, setCurrentUserID] = useState(null);
  const [groupMembers, setGroupMembers] = useState([]);
  const [groupNameSearchQuery, setGroupNameSearchQuery] = useState('');
  const [fileSearchQuery, setFileSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState('asc');
  const [memberName, setMemberName] = useState('');
  const [isAdmin, setIsAdmin] = useState(false); // State to track if the current user is the admin
  const [contactNoToAdd, setContactNoToAdd] = useState(''); // State to manage the contact number to add to the group
  const [displayedSection, setDisplayedSection] = useState('file'); // State to manage which section is displayed: file, members, leaveGroup
  const [isPrivate, setIsPrivate] = useState(false); // State to track private/public mode
  const [popupVisible, setPopupVisible] = useState(false); // State to manage the visibility of the pop-up
  const [enteredContactNo, setEnteredContactNo] = useState(''); // State to manage the entered contact number

  useEffect(() => {
    const fetchCurrentUserID = async () => {
      try {
        const response = await axios.get('http://localhost/RMI/PHP/gc_get_user_id.php', {
          params: {
            senderContactNo: senderContactNo
          }
        });
        setCurrentUserID(response.data.id);
      } catch (error) {
        console.error('Error fetching current user ID:', error);
      }
    };

    fetchCurrentUserID();
  }, [senderContactNo]);

  useEffect(() => {
    const fetchGroupNames = async () => {
      try {
        const response = await axios.get('http://localhost/RMI/PHP/get_group_names.php', {
          params: {
            senderContactNo: senderContactNo
          }
        });
        setGroupNames(response.data);
      } catch (error) {
        console.error('Error fetching group names:', error);
      }
    };

    fetchGroupNames();
  }, [senderContactNo]);

  useEffect(() => {
    const fetchData = async () => {
      if (selectedGroup) {
        fetchChatHistory(selectedGroup);
        await fetchFileHistory(selectedGroup);
        await fetchGroupMembers(selectedGroup);
        checkAdminStatus(); // Check if the current user is the admin of the group
      }
    };

    fetchData();
    const intervalId = setInterval(fetchData, 5000);

    return () => clearInterval(intervalId);
  }, [selectedGroup]);

  const fetchChatHistory = async (selectedGroup) => {
    try {
      const response = await axios.get(`http://localhost/RMI/PHP/get_groupchat_history.php`, {
        params: {
          group_name: selectedGroup
        }
      });

      setChatHistory(response.data);
    } catch (error) {
      console.error('Error fetching chat history:', error);
    }
  };

  const fetchFileHistory = async (selectedGroup) => {
    try {
      const response = await axios.get(`http://localhost/RMI/PHP/get_groupfile_history.php`, {
        params: {
          group_name: selectedGroup
        }
      });
      setFileHistory(response.data);
    } catch (error) {
      console.error('Error fetching file history:', error);
    }
  };

  const fetchGroupMembers = async (selectedGroup) => {
    try {
      const response = await axios.get(`http://localhost/RMI/PHP/get_group_members.php`, {
        params: {
          group_name: selectedGroup
        }
      });
      setGroupMembers(response.data);
    } catch (error) {
      console.error('Error fetching group members:', error);
    }
  };

  const checkAdminStatus = async () => {
    try {
      const response = await axios.get(`http://localhost/RMI/PHP/check_admin_status.php`, {
        params: {
          group_name: selectedGroup,
          senderContactNo: senderContactNo
        }
      });
      setIsAdmin(response.data.isAdmin);
      console.log('isAdmin:', response.data.isAdmin);
    } catch (error) {
      console.error('Error checking admin status:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      formData.append('group_id', selectedGroup);
      formData.append('senderContactNo', senderContactNo);

      // Check if message is empty but file is present
      if (!message.trim() && file) {
        formData.append('message', `I have sent a file named ${file.name}. Please check it in the file history.`);
      } else if (message.trim()) { // Only append the message if it's not empty
        formData.append('message', message);
      }

      formData.append('file', file);
      formData.append('contact_no', contactNoToAdd); // Add contact number to add to the group

      const response = await axios.post('http://localhost/RMI/PHP/send_group_message.php', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      setMessage('');
      setFile(null);
    } catch (error) {
      console.error('Error sending group message:', error);
    }
  };

  const handleChange = (e) => {
    setMessage(e.target.value);
  };

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleContactNoChange = (e) => {
    setContactNoToAdd(e.target.value);
  };

  const handleAddContact = async () => {
    try {
      const formData = new FormData();
      formData.append('contact_no', contactNoToAdd); // Add contact number to add to the group
      formData.append('group_id', selectedGroup); // Add selected group id
      formData.append('senderContactNo', senderContactNo); // Add sender contact number

      const response = await axios.post('http://localhost/RMI/PHP/add_contact_to_group.php', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      console.log(response.data); // Log the response from the server
    } catch (error) {
      console.error('Error adding contact to group:', error);
    }
  };

  const downloadGroupFile = async (fileName) => {
    try {
      const response = await axios.get(`http://localhost/RMI/PHP/download_groupfile.php?filename=${fileName}`, {
        responseType: 'blob'
      });

      const downloadUrl = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.setAttribute('download', fileName);
      document.body.appendChild(link);
      link.click();
      link.parentNode.removeChild(link);
    } catch (error) {
      console.error('Error downloading file:', error);
    }
  };

  const leaveGroup = async () => {
    try {
      const formData = new FormData();
      formData.append('group_name', selectedGroup); // Add group_name parameter
      formData.append('senderContactNo', senderContactNo); // Add senderContactNo parameter

      const response = await axios.post('http://localhost/RMI/PHP/leave_group.php', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      // Optionally, you can handle success response here, for example, redirect to home page
      console.log('Successfully left the group');
    } catch (error) {
      console.error('Error leaving group:', error);
    }
  };

  // Sort group names alphabetically
  const sortedGroupNames = groupNames.sort((a, b) => {
    if (sortOrder === 'asc') {
      return a.localeCompare(b);
    } else {
      return b.localeCompare(a);
    }
  });

  // Filter group names based on search query
  const filteredGroupNames = sortedGroupNames.filter(groupName =>
    groupName.toLowerCase().includes(groupNameSearchQuery.toLowerCase())
  );

  // Filter file history based on search query
  const filteredFileHistory = fileHistory.filter(file =>
    file.file_name.toLowerCase().includes(fileSearchQuery.toLowerCase())
  );

  console.log('selectedGroup:', selectedGroup);
  console.log('isAdmin:', isAdmin);
  console.log('contactNoToAdd:', contactNoToAdd);

  // Update the togglePrivate function to manage the pop-up visibility
  const togglePrivate = () => {
    if (!isPrivate) {
      setIsPrivate(true); // Proceed to go private
    } else {
      setPopupVisible(true); // Display the pop-up for entering contact number
    }
  };

  // Function to handle the submission of the contact number
  const handleContactNoSubmit = () => {
    // Check if the entered contact number matches the sender's contact number
    if (enteredContactNo === senderContactNo) {
      setIsPrivate(false); // Proceed to go public
    }
    setPopupVisible(false); // Close the pop-up
    setEnteredContactNo('');
  };

  return (
    <div className="message-form-container">
      <div className="sidenav">
        <h2>Group Chats</h2>
        {/* Add search input for group names */}
        <input
          type="text"
          value={groupNameSearchQuery}
          onChange={(e) => setGroupNameSearchQuery(e.target.value)}
          placeholder="Search group name"
          className="group-name-search-input" // Add custom class here
        />
        {/* Render the "Private" button with toggle functionality */}
        <button onClick={togglePrivate}>{isPrivate ? 'Default' : 'Private'}</button>
        <div className='individualorgroupchat'>
          {/* Button for individual message */}
          <button onClick={() => navigate('/message-form')}>
            <img src={personImage} alt="Individual" />
          </button>
          {/* Button for group message */}
          <button onClick={() => navigate('/group-message-form')}>
            <img src={groupImage} alt="Group" />
          </button>
        </div>

        <ul>
          {/* Render filtered and sorted group names */}
          {filteredGroupNames.map((groupName, index) => (
            <li
              key={index}
              onClick={() => setSelectedGroup(groupName)}
              className={`group-list-item ${selectedGroup === groupName ? 'selected' : ''}`}
            >
              <div className="circle-container">{groupName.charAt(0)}</div>
              <div className="recipient-name">{groupName}</div>
            </li>
          ))}
        </ul>


      </div>

      {/* Render the pop-up for entering contact number */}
      {popupVisible && (
        <div className="popup">
          <input
            type="text"
            value={enteredContactNo}
            onChange={(e) => setEnteredContactNo(e.target.value)}
            placeholder="Enter contact number"
          />
          <button onClick={handleContactNoSubmit}>Submit</button>
        </div>
      )}

      {/* Render other sections based on selected group */}
      {selectedGroup && (
        <div className="main-content">
          <div className="chat-history">
            <h2>Chat History</h2>
            <ul>
              {chatHistory.map((chat, index) => {
                const isCurrentUser = chat.members_id === currentUserID;
                return (
                  <div
                    key={index}
                    className={isCurrentUser ? 'sent' : 'received'}
                    style={{ filter: isPrivate ? 'blur(3px)' : 'none' }}
                  >
                    {!isCurrentUser && <span className="name">{chat.name}: </span>}
                    {chat.message}
                  </div>
                );
              })}
            </ul>
          </div>

          <div className="message-form">
            <form onSubmit={handleSubmit} encType="multipart/form-data">
              <textarea name="message" value={message} onChange={handleChange} placeholder="Message" rows="4" />
              <input type="file" name="file" onChange={handleFileChange} accept=".jpg,.jpeg,.png,.doc,.docx,.pdf" />
              <button type="submit">Send Message</button>
            </form>
          </div>

        </div>
      )}

      {/* Render other sections based on selected group */}
      {selectedGroup && (
        <div className="file-history-container">
          <div className="toggle-buttons">
            <button onClick={() => setDisplayedSection('file')}>File</button>
            <button onClick={() => setDisplayedSection('members')}>Members</button>
            <button onClick={() => setDisplayedSection('leaveGroup')}>LeaveGroup</button>
            <button onClick={() => setDisplayedSection('contact')}>Add Contact</button>
          </div>
          <div className="file-history" style={{ display: displayedSection === 'file' ? 'block' : 'none' }}>
            <h2>File History</h2>
            {/* Add search input for files */}
            <input
              type="text"
              value={fileSearchQuery}
              onChange={(e) => setFileSearchQuery(e.target.value)}
              placeholder="Search file"
            />

            {/* Render filtered file history */}
            {filteredFileHistory.map((file, index) => (
              <p key={index}>
                <strong>Name:</strong> {file.file_name}
                <br />
                {/* Render download button only if file name is not empty */}
                {file.file_name && (
                  <button onClick={() => downloadGroupFile(file.file_name)}>Download</button>
                )}
              </p>
            ))}

            {/* Add Contact section */}
          </div>
          {isAdmin && (
            <div className="add-contact-section" style={{ display: displayedSection === 'contact' ? 'block' : 'none' }}>
              <input
                type="text"
                value={contactNoToAdd}
                onChange={handleContactNoChange}
                placeholder="Enter contact number"
              />
              <button onClick={handleAddContact}>Add Contact</button>
            </div>
          )}
          <div className="members-container" style={{ display: displayedSection === 'members' ? 'block' : 'none' }}>
            <h2>Members</h2>
            <ul>
              {groupMembers.map((member, index) => (
                <li key={index}>
                  {member}
                </li>
              ))}
            </ul>
          </div>
          <div className="leave-group-container" style={{ display: displayedSection === 'leaveGroup' ? 'block' : 'none' }}>
            <h3>Leave Group</h3>
            <button onClick={leaveGroup}>Leave</button>
          </div>
        </div>
      )}

    </div>
  );
};

export default GroupMessageForm;
