import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './messageform.css';
import personImage from '../images/person.png'; // Import individual image
import groupImage from '../images/group.png'; // Import group image
import { useNavigate } from 'react-router-dom';

const MessageForm = ({ senderContactNo }) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    recipientContactNo: '',
    message: '',
    file: null
  });

  const [recipients, setRecipients] = useState([]);
  const [chatHistory, setChatHistory] = useState([]);
  const [fileHistory, setFileHistory] = useState([]);
  const [selectedRecipient, setSelectedRecipient] = useState(null);
  const [showFileHistory, setShowFileHistory] = useState(false);
  const [recipientSearchQuery, setRecipientSearchQuery] = useState('');
  const [fileSearchQuery, setFileSearchQuery] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [popupVisible, setPopupVisible] = useState(false);
  const [enteredContactNo, setEnteredContactNo] = useState('');

  const handleChange = (e) => {
    const { name, value, files } = e.target;

    if (name === 'file') {
      const file = files[0];
      if (file) {
        setFormData(prevState => ({
          ...prevState,
          [name]: file
        }));
      } else {
        setFormData(prevState => ({
          ...prevState,
          [name]: null
        }));
      }
    } else {
      setFormData(prevState => ({
        ...prevState,
        [name]: value
      }));
    }
  };

  const handleRecipientClick = (recipient) => {
    setSelectedRecipient(recipient);
    fetchChatHistory(senderContactNo, recipient);
    setShowFileHistory(true);

    setFormData(prevState => ({
      ...prevState,
      recipientContactNo: recipient
    }));
  };

  const fetchRecipients = async () => {
    try {
      const response = await axios.get('http://localhost/RMI/PHP/get_recipients.php', {
        params: { senderContactNo }
      });
      const sortedRecipients = response.data.sort((a, b) => a.name.localeCompare(b.name));
      setRecipients(sortedRecipients);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchChatHistory = async (sender, recipient) => {
    try {
      const response = await axios.get(`http://localhost/RMI/PHP/get_chat_history.php`, {
        params: {
          senderContactNo: sender,
          recipient: recipient
        }
      });
      setChatHistory(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchFileHistory = async (sender, recipient) => {
    try {
      const response = await axios.get(`http://localhost/RMI/PHP/get_file_history.php`, {
        params: {
          senderContactNo: sender,
          receiverContactNo: recipient
        }
      });
      setFileHistory(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      let messageToSend = formData.message.trim();
      if (!messageToSend && formData.file) {
        messageToSend = `I have sent a file named ${formData.file.name}. Please check it in the file history.`;
      }

      const data = new FormData();
      data.append('senderContactNo', senderContactNo);
      data.append('contactNo', formData.recipientContactNo);
      data.append('message', messageToSend);
      data.append('file', formData.file);

      const response = await axios.post('http://localhost/RMI/PHP/upload_file.php', data);
      console.log(response.data);

      if (messageToSend) {
        setChatHistory(prevChatHistory => [...prevChatHistory, { sender_contact_no: senderContactNo, message: messageToSend }]);
      }

      setFormData({
       
        message: '',
        file: null
      });
    } catch (error) {
      console.error(error);
    }
  };

  const filterRecipients = (recipient) => {
    return recipient.name.toLowerCase().includes(recipientSearchQuery.toLowerCase());
  };

  const filterFiles = (file) => {
    return file.file_name.toLowerCase().includes(fileSearchQuery.toLowerCase());
  };

  const togglePrivate = () => {
    if (!isPrivate) {
      setIsPrivate(true);
    } else {
      setPopupVisible(true);
    }
  };

  const handleContactNoSubmit = () => {
    if (enteredContactNo === senderContactNo) {
      setIsPrivate(false);
    }
    setPopupVisible(false);
    setEnteredContactNo('');
  };

  const handleRecipientSearch = (e) => {
    setRecipientSearchQuery(e.target.value);
  };

  const handleFileSearch = (e) => {
    setFileSearchQuery(e.target.value);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      fetchRecipients();
    }, 500);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      if (senderContactNo && selectedRecipient) {
        fetchChatHistory(senderContactNo, selectedRecipient);
      }
    }, 500);

    return () => clearInterval(interval);
  }, [senderContactNo, selectedRecipient]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (selectedRecipient) {
        fetchFileHistory(senderContactNo, selectedRecipient);
      }
    }, 500);

    return () => clearInterval(interval);
  }, [senderContactNo, selectedRecipient]);

  return (
    <>
      <div className="message-form-container">
        <div className="sidenav">
          <h2>Recipients</h2>
          <div className="recipient-options">
            <div className="search-container">
              <input type="text" value={recipientSearchQuery} onChange={handleRecipientSearch} placeholder="Search Recipients" />
              <button onClick={togglePrivate}>{isPrivate ? 'Default' : 'Private'}</button>
            </div>
          </div>
          <div className='individualorgroupchat'>
            <button onClick={() => navigate('/message-form')}>
              <img src={personImage} alt="Individual" />
            </button>
            <button onClick={() => navigate('/group-message-form')}>
              <img src={groupImage} alt="Group" />
            </button>
          </div>
          <ul>
            {recipients.filter(filterRecipients).map(recipient => (
              <li key={recipient.contact_no} onClick={() => handleRecipientClick(recipient.contact_no)} className={selectedRecipient === recipient.contact_no ? 'active' : ''}>
                <div className="recipient-info">
                  <div className="circle-container">{recipient.name.charAt(0)}</div>
                  <div className="recipient-name">{recipient.name}</div>
                </div>
              </li>
            ))}
          </ul>
        </div>
        {popupVisible && (
          <div className="popup">
            <input
              type="text"
              value={enteredContactNo}
              onChange={(e) => setEnteredContactNo(e.target.value)}
              placeholder="Enter contact number"
            />
            <button onClick={handleContactNoSubmit}>Submit</button>
          </div>
        )}
        <div className="main-content">
          <h2>Chat History</h2>
          <div className="chat-history">
            <ul style={{ filter: isPrivate ? 'blur(3px)' : 'none' }}>
              {chatHistory.map((message, index) => (
                <li key={index} className={message.sender_contact_no === senderContactNo ? 'sent' : 'received'}>
                  {message.message}
                </li>
              ))}
            </ul>
          </div>
          <div className="message-form">
            <form onSubmit={handleSubmit} encType="multipart/form-data">
              <input type="text" name="recipientContactNo" value={formData.recipientContactNo} onChange={handleChange} placeholder="Recipient's Contact Number" required />
              <textarea name="message" value={formData.message} onChange={handleChange} placeholder="Message" rows="4" />
              <input type="file" name="file" onChange={handleChange} accept=".jpg,.jpeg,.png,.doc,.docx,.pdf" />
              <button type="submit">Send Message</button>
            </form>
          </div>
        </div>
        {showFileHistory && selectedRecipient && (
          <div className="file-history-container">
            <div className="file-history">
              <h2>File History</h2>
              <input type="text" value={fileSearchQuery} onChange={handleFileSearch} placeholder="Search File" />
              <ul>
                {fileHistory.filter(filterFiles).map((file, index) => (
                  <li key={index}>
                    {file.file_name && (
                      <>
                        <strong>Name:</strong> {file.file_name}<br />
                        {file.file_name && <a href={`http://localhost/RMI/PHP/download_file.php?filename=${file.file_name}`} download>Download</a>}
                      </>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default MessageForm;
