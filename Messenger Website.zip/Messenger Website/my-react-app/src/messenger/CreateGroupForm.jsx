import React, { useState } from 'react';
import axios from 'axios';
import './CreateGroupForm.css'; // Import the CSS file

const CreateGroupForm = () => {
  const [formData, setFormData] = useState({
    groupName: '',
    adminContactNo: '', 
    contactNo: '',
    memberList: []
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value || ''
    }));
  };

  const handleAddMember = () => {
    if (formData.contactNo.trim() !== '') {
      setFormData(prevState => ({
        ...prevState,
        memberList: [...prevState.memberList, formData.contactNo],
        contactNo: ''
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log('Form Data:', formData); 
    try {
      const response = await axios.post('http://localhost/RMI/PHP/add_group_chat.php', {
        ...formData,
        memberList: JSON.stringify(formData.memberList)
      }, {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      });
      console.log(response.data);
      setFormData({
        groupName: '',
        adminContactNo: '', 
        contactNo: '',
        memberList: []
      });
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <>
    <div className='background-create-group-form'>
    <div className="create-group-form-container"> {/* Apply the class here */}
      
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="groupName">Group Name:</label>
          <input type="text" id="groupName" name="groupName" value={formData.groupName} onChange={handleChange} required />
        </div>
        <div className="form-group">
          <label htmlFor="adminContactNo">Admin Contact No:</label>
          <input type="text" id="adminContactNo" name="adminContactNo" value={formData.adminContactNo} onChange={handleChange} required />
        </div>
        <div className="form-group">
          <label>Group Members:</label>
          <ul>
            {formData.memberList.map((member, index) => (
              <li key={index}>{member}</li>
            ))}
          </ul>
        </div>
        <div className="form-group">
          <label htmlFor="contactNo">Contact Number:</label>
          <input type="text" id="contactNo" name="contactNo" value={formData.contactNo} onChange={handleChange} />
          <div className="button-group">
            <button type="button" onClick={handleAddMember}>Add Member</button>
            
            <button type="submit">Create Group Chat</button>
          </div>
        </div>
      </form>
    </div>

    </div>
   
    </>
  );
};

export default CreateGroupForm;
