<?php
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;

require __DIR__ . '/../vendor/autoload.php';

class Chat implements MessageComponentInterface {
    protected $clients;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        echo "New connection! ({$conn->resourceId})\n";
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);

        switch ($data['type']) {
            case 'fetchMessageHistory':
                $messageHistory = $this->fetchMessageHistoryFromDatabase($data['senderContactNo'], $data['recipientContactNo']);
                $from->send(json_encode([
                    'type' => 'messageHistory',
                    'messages' => $messageHistory
                ]));
                break;
            default:
                foreach ($this->clients as $client) {
                    $client->send(json_encode($data));
                }
                break;
        }
    }

    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);
        echo "Connection {$conn->resourceId} has disconnected\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";
        $conn->close();
    }

    private function fetchMessageHistoryFromDatabase($senderContactNo, $recipientContactNo) {
        // Example implementation to fetch message history from the database
        // This is a placeholder and should be replaced with your actual database query
        // Make sure to sanitize input and handle errors appropriately

        // Assuming you're using PDO for database operations
        $pdo = new PDO('mysql:host=localhost;dbname=rmi', 'root', '');
        $stmt = $pdo->prepare('SELECT * FROM messages WHERE sender_contact = :sender AND recipient_contact = :recipient');
        $stmt->bindParam(':sender', $senderContactNo);
        $stmt->bindParam(':recipient', $recipientContactNo);
        $stmt->execute();
        $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $messages;
    }
}

$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new Chat()
        )
    ),
    8080
);

echo "WebSocket server started\n";
$server->run();
?>
