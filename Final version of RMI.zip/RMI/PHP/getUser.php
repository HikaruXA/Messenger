<?php
// Allow requests from the specified origin (replace http://localhost:5173 with your frontend URL)
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");

// If the request method is OPTIONS, respond with CORS headers and exit
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Origin: http://localhost:5173");
    header("Access-Control-Allow-Methods: GET");
    header("Access-Control-Allow-Headers: Content-Type");
    exit;
}

// Process the GET request
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Retrieve user ID from query parameters
    $userId = $_GET['id'] ?? '';

    // Connect to MySQL database
    $servername = "localhost"; // Replace with your MySQL server name
    $username = "root"; // Replace with your MySQL username
    $db_password = ""; // Replace with your MySQL password
    $dbname = "rmi"; // Replace with your MySQL database name

    try {
        // Set PDO error mode to exception
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $db_password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Prepare SQL statement to fetch user name based on user ID
        $stmt = $conn->prepare("SELECT name FROM users WHERE id = :userId");
        $stmt->bindParam(':userId', $userId);
        $stmt->execute();

        // Fetch user name
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        // Respond with user name
        echo json_encode($result);
    } catch(PDOException $e) {
        // Respond with error message
        echo json_encode(array("error" => "Error: " . $e->getMessage()));
    }

    // Close database connection
    $conn = null;
}
?>
