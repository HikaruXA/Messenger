<?php
// Allow requests from the specific origin
header("Access-Control-Allow-Origin: http://localhost:5173");

// Allow the appropriate HTTP methods
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

// Allow the Content-Type header
header("Access-Control-Allow-Headers: Content-Type");

// If the request method is OPTIONS, respond with a 200 status code and exit
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$database = "rmi";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data to prevent SQL injection
    $senderContactNo = isset($_POST['senderContactNo']) ? mysqli_real_escape_string($conn, $_POST['senderContactNo']) : '';
    $group_id = isset($_POST['group_id']) ? mysqli_real_escape_string($conn, $_POST['group_id']) : '';
    $message = isset($_POST['message']) ? mysqli_real_escape_string($conn, $_POST['message']) : '';

    // File upload
    $file_name = ''; // Initialize file name variable
    if (!empty($_FILES['file']['name'])) {
        $file_name = $_FILES['file']['name'];
        $file_tmp = $_FILES['file']['tmp_name'];
        $file_path = 'D:/Xampp/htdocs/RMI/group_uploads/' . $file_name; // Specify the server directory
        move_uploaded_file($file_tmp, $file_path); // Move the uploaded file to the server directory
    } else {
        // Set file name to NULL if it's empty
        $file_name = NULL;
    }

    // Fetch membersId based on senderContactNo
    $sqlSender = "SELECT id FROM users WHERE contact_no = '$senderContactNo'";
    $resultSender = $conn->query($sqlSender);

    if ($resultSender->num_rows > 0) {
        $rowSender = $resultSender->fetch_assoc();
        $members_id = $rowSender['id'];

        // Fetch group ID based on the provided group_id
        $sqlGroup = "SELECT group_id FROM groupchat WHERE group_name = '$group_id'";
        $resultGroup = $conn->query($sqlGroup);

        if ($resultGroup->num_rows > 0) {
            $rowGroup = $resultGroup->fetch_assoc();
            $actual_group_id = $rowGroup['group_id'];

            // Insert data into groupmessage table
            $sql_groupmessage = "INSERT INTO groupmessage (members_id, group_id, message, file_name) VALUES ('$members_id', '$actual_group_id', '$message', ?)";
            $stmt = $conn->prepare($sql_groupmessage);
            $stmt->bind_param("s", $file_name);

            if ($stmt->execute()) {
                // Echo all the inserted values
                echo "Data inserted successfully.<br>";
                echo "members_id: " . $members_id . "<br>";
                echo "group_id: " . $actual_group_id . "<br>";
                echo "message: " . $message . "<br>";
                echo "file_name: " . $file_name . "<br>";
            } else {
                echo "Error: " . $sql_groupmessage . "<br>" . $conn->error;
            }
        } else {
            echo "No group found with the provided group_id: $group_id";
        }
    } else {
        echo "No user found with the provided senderContactNo: $senderContactNo";
    }
}

// Close connection
$conn->close();
?>
