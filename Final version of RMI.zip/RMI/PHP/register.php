<?php
// Allow requests from the specified origin (replace http://localhost:5173 with your frontend URL)
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// If the request method is OPTIONS, respond with CORS headers and exit
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Origin: http://localhost:5173");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Allow-Headers: Content-Type");
    exit;
}

// Process the POST request
// Process the POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $name = $_POST['name'] ?? '';
    $contactNo = $_POST['contactNo'] ?? '';
    $password = $_POST['password'] ?? '';
    $bio = $_POST['bio'] ?? ''; // New field for bio
    $status = 'offline'; // Default status

    // Encrypt the password
    $encryption_key = "1234"; // Replace with your encryption key
    $encrypted_password = openssl_encrypt($password, "AES-128-ECB", $encryption_key);

    // Connect to MySQL database
    $servername = "localhost"; // Replace with your MySQL server name
    $username = "root"; // Replace with your MySQL username
    $db_password = ""; // Replace with your MySQL password
    $dbname = "rmi"; // Replace with your MySQL database name

    try {
        // Set PDO error mode to exception
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $db_password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Insert data into the 'users' table
        $stmt = $conn->prepare("INSERT INTO users (name, contact_no, password) VALUES (:name, :contactNo, :password)");
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':contactNo', $contactNo); // Directly bind contact number
        $stmt->bindParam(':password', $encrypted_password); // Use encrypted password
        $stmt->execute();

        // Get the user_id of the inserted user
        $user_id = $conn->lastInsertId();

        // Insert data into the 'userprofile' table
        $stmt_profile = $conn->prepare("INSERT INTO userprofile (user_id, bio, status, profile_name) VALUES (:user_id, :bio, :status, :profile_name)");
        $stmt_profile->bindParam(':user_id', $user_id);
        $stmt_profile->bindParam(':bio', $bio);
        $stmt_profile->bindParam(':status', $status);
        $profile_name = $_FILES['profilePicture']['name'];
        $stmt_profile->bindParam(':profile_name', $profile_name);
        $stmt_profile->execute();

        // Upload profile picture
        $target_dir = "D:/Xampp/htdocs/RMI/profile_uploads/";
        $target_file = $target_dir . basename($profile_name);
        move_uploaded_file($_FILES['profilePicture']['tmp_name'], $target_file);

        // Respond with success message
        echo json_encode(array("message" => "User registered successfully"));
    } catch(PDOException $e) {
        // Respond with error message
        echo json_encode(array("error" => "Error: " . $e->getMessage()));
    }

    // Close database connection
    $conn = null;
}

?>
