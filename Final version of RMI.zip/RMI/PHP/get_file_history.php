<?php
// Allow requests from the specified origin (replace http://localhost:5173 with your frontend URL)
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type");

// If the request method is OPTIONS, respond with CORS headers and exit
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Origin: http://localhost:5173");
    header("Access-Control-Allow-Methods: GET, POST");
    header("Access-Control-Allow-Headers: Content-Type");
    exit;
}

// Connect to MySQL database
$servername = "localhost"; // Replace with your MySQL server name
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$dbname = "rmi"; // Replace with your MySQL database name

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch file history for both sender and recipient
   $stmt = $conn->prepare("SELECT file_name FROM messages WHERE ((sender_contact_no = :senderContactNo AND receiver_contact_no = :receiverContactNo) OR (sender_contact_no = :receiverContactNo AND receiver_contact_no = :senderContactNo)) AND file_name IS NOT NULL");

    $stmt->bindParam(':senderContactNo', $_GET['senderContactNo']);
    $stmt->bindParam(':receiverContactNo', $_GET['receiverContactNo']);
    $stmt->execute();
    $fileHistory = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Respond with the file history
    echo json_encode($fileHistory);
} catch(PDOException $e) {
    // Respond with error message
    echo json_encode(array("error" => "Error: " . $e->getMessage()));
}

// Close database connection
$conn = null;
?>
