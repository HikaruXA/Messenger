<?php

header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$database = "rmi";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve contact number and group name from the request
    $contactNo = $_POST['contact_no'];
    $groupName = $_POST['group_id'];
    $senderContactNo = $_POST['senderContactNo'];

    // Query to check if the member exists in the users table
    $checkMemberSql = "SELECT id FROM users WHERE contact_no = '$contactNo'";
    $memberResult = $conn->query($checkMemberSql);

    // Query to fetch the sender's ID
    $checkSenderSql = "SELECT id FROM users WHERE contact_no = '$senderContactNo'";
    $senderResult = $conn->query($checkSenderSql);

    // If member exists, proceed with adding them to the group
    if ($memberResult->num_rows > 0) {
        // Fetch member's ID
        $memberRow = $memberResult->fetch_assoc();
        $memberId = $memberRow['id'];

        // If sender exists, proceed with the operation
        if ($senderResult->num_rows > 0) {
            // Fetch sender's ID
            $senderRow = $senderResult->fetch_assoc();
            $senderId = $senderRow['id'];

            // Query to fetch the group ID and admin ID based on the provided group name
            $getGroupInfoSql = "SELECT group_id, admin_id FROM groupchat WHERE group_name = '$groupName'";
            $groupInfoResult = $conn->query($getGroupInfoSql);

            // If group exists, proceed with adding member to the group
            if ($groupInfoResult->num_rows > 0) {
                // Fetch group ID and admin ID
                $groupRow = $groupInfoResult->fetch_assoc();
                $groupId = $groupRow['group_id'];
                $adminId = $groupRow['admin_id'];

                // Check if the current user is the admin of the group
                if ($adminId == $senderId) {
                    // Insert member into groupmembers table
                    $sqlGroupMembers = "INSERT INTO groupmembers (members_id, group_id) VALUES ('$memberId', '$groupId')";
                    if ($conn->query($sqlGroupMembers) !== TRUE) {
                        // Handle insertion error if any
                        echo "Error adding member: " . $conn->error;
                    } else {
                        // Success message if member added successfully
                        echo "Contact added to the group successfully";
                    }
                } else {
                    // Error message if the current user is not the admin of the group
                    echo "Error: You are not authorized to add members to this group";
                }
            } else {
                // Error message if group doesn't exist
                echo "Error: Group '$groupName' does not exist";
            }
        } else {
            // Error message if sender doesn't exist
            echo "Error: Sender contact number '$senderContactNo' does not exist in the users table";
        }
    } else {
        // Error message if member doesn't exist in users table
        echo "Error: Member contact number '$contactNo' does not exist in the users table";
    }
} else {
    // Error message for invalid request method
    echo "Invalid request method";
}

?>
