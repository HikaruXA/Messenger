<?php
// Retrieve the file name from the query parameters
$filename = $_GET['filename'];

// Directory where files are stored
$uploadDirectory = "D:/Xampp/htdocs/RMI/uploads/";

// Path to the file
$filePath = $uploadDirectory . $filename;

// Check if the file exists
if (file_exists($filePath)) {
    // Set appropriate headers for the file download
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . filesize($filePath));

    // Read the file and output its contents
    readfile($filePath);
} else {
    // File not found, send 404 Not Found response
    http_response_code(404);
    echo "File not found.";
}
?>
