<?php
// Allow requests from any origin
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to the database
    $servername = "localhost"; // Replace with your MySQL server name
    $username = "root"; // Replace with your MySQL username
    $password = ""; // Replace with your MySQL password
    $dbname = "rmi"; // Replace with your MySQL database name
    
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get form data
    $senderContactNo = $_POST['senderContactNo'];
    $receiverContactNo = $_POST['contactNo']; // Updated field name
    $message = $_POST['message'] ?? null;

    // Encrypt the message with the key "1234"
    $encryption_key = "1234";
    $encrypted_message = openssl_encrypt($message, "AES-128-ECB", $encryption_key);

    // Check if the receiver contact number exists in the users table
    $stmt = $pdo->prepare("SELECT COUNT(*) AS count FROM users WHERE contact_no = :receiverContactNo");
    $stmt->bindParam(':receiverContactNo', $receiverContactNo);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result['count'] == 0) {
        // If receiver contact number does not exist in users table, return an error message
        echo json_encode(array("success" => false, "error" => "Receiver contact number does not exist in the users table."));
        exit;
    }

    // Handle file upload if a file is provided
    if (isset($_FILES["file"]) && $_FILES["file"]["error"] == UPLOAD_ERR_OK) {
        $uploadDirectory = "D:/Xampp/htdocs/RMI/uploads/"; // Change to your upload directory
        $fileName = $_FILES["file"]["name"];
        $filePath = $uploadDirectory . $fileName;
        move_uploaded_file($_FILES["file"]["tmp_name"], $filePath);
    } else {
        // If no file is uploaded, set file name to null
        $fileName = null;
    }

    // Insert data into database
    try {
        $stmt = $pdo->prepare("INSERT INTO messages (sender_contact_no, receiver_contact_no, message, file_name) VALUES (:senderContactNo, :receiverContactNo, :message, :file_name)");
        $stmt->bindParam(':senderContactNo', $senderContactNo);
        $stmt->bindParam(':receiverContactNo', $receiverContactNo); // Updated field binding
        $stmt->bindParam(':message', $encrypted_message, PDO::PARAM_STR); // Insert encrypted message
        $stmt->bindParam(':file_name', $fileName, PDO::PARAM_STR);
        $stmt->execute();
        
        echo json_encode(array("success" => true, "message" => "Message inserted successfully."));
    } catch(PDOException $e) {
        echo json_encode(array("success" => false, "error" => "Error inserting message into the database: " . $e->getMessage()));
    }
} else {
    // Respond with an error message if the request method is not POST
    echo json_encode(array("success" => false, "message" => "Invalid request method."));
}
?>
