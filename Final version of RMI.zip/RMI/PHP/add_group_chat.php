<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$database = "rmi";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $group_name = isset($_POST['groupName']) ? mysqli_real_escape_string($conn, $_POST['groupName']) : '';
    $admin_contact_no = isset($_POST['adminContactNo']) ? mysqli_real_escape_string($conn, $_POST['adminContactNo']) : '';
    $memberList = isset($_POST['memberList']) ? json_decode($_POST['memberList']) : [];

    echo "Group Name: " . $group_name . "<br>";
    echo "Admin Contact No: " . $admin_contact_no . "<br>";
    echo "Group Members: " . implode(', ', $memberList) . "<br>";

    // Check if admin_contact_no exists in the users table
    $check_user_sql = "SELECT id FROM users WHERE contact_no = '$admin_contact_no'";
    $result = $conn->query($check_user_sql);
    if ($result->num_rows == 0) {
        echo "Error: Admin contact number does not exist in the users table";
        exit;
    }

    $admin_row = $result->fetch_assoc();
    $admin_id = $admin_row['id'];

    // Insert data into groupchat table
    $sql_groupchat = "INSERT INTO groupchat (group_name, admin_id) VALUES ('$group_name', '$admin_id')";
    if ($conn->query($sql_groupchat) === TRUE) {
        $last_inserted_group_id = $conn->insert_id;

        // Iterate through the memberList and insert each member into groupmembers table
        foreach ($memberList as $member) {
            // Check if the member exists in the users table
            $check_member_sql = "SELECT id FROM users WHERE contact_no = '$member'";
            $member_result = $conn->query($check_member_sql);
            if ($member_result->num_rows > 0) {
                $member_row = $member_result->fetch_assoc();
                $member_id = $member_row['id'];

                // Insert member into groupmembers table
                $sql_groupmembers = "INSERT INTO groupmembers (members_id, group_id) VALUES ('$member_id', '$last_inserted_group_id')";
                if ($conn->query($sql_groupmembers) !== TRUE) {
                    echo "Error adding member: " . $conn->error;
                }
            } else {
                echo "Error: Member contact number '$member' does not exist in the users table";
            }
        }

        echo "New group created successfully";
    } else {
        echo "Error creating group: " . $conn->error;
    }

    $conn->close();
}
?>
