<?php
// Allow requests from the specified origin (replace http://localhost:5173 with your frontend URL)
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type");

// If the request method is OPTIONS, respond with CORS headers and exit
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Origin: http://localhost:5173");
    header("Access-Control-Allow-Methods: GET, POST");
    header("Access-Control-Allow-Headers: Content-Type");
    exit;
}

// Connect to MySQL database
$servername = "localhost"; // Replace with your MySQL server name
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$dbname = "rmi"; // Replace with your MySQL database name

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch all messages between the sender and receiver
    $stmt = $conn->prepare("SELECT sender_contact_no, message FROM messages WHERE (sender_contact_no = :senderContactNo AND receiver_contact_no = :receiverContactNo) OR (sender_contact_no = :receiverContactNo AND receiver_contact_no = :senderContactNo)");
    $stmt->bindParam(':senderContactNo', $_GET['senderContactNo']);
    $stmt->bindParam(':receiverContactNo', $_GET['recipient']);
    $stmt->execute();
    $chatHistory = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Decrypt each message using the key "1234"
    $decryptedChatHistory = array();
    foreach ($chatHistory as $message) {
        $decryptedMessage = openssl_decrypt($message['message'], "AES-128-ECB", "1234");
        $decryptedChatHistory[] = array(
            "sender_contact_no" => $message['sender_contact_no'],
            "message" => $decryptedMessage
        );
    }

    // Respond with the decrypted chat history
    echo json_encode($decryptedChatHistory);
} catch(PDOException $e) {
    // Respond with error message
    echo json_encode(array("error" => "Error: " . $e->getMessage()));
}

// Close database connection
$conn = null;
?>
