<?php
// Allow requests from the specific origin
header("Access-Control-Allow-Origin: http://localhost:5173");

// Allow the appropriate HTTP methods
header("Access-Control-Allow-Methods: GET");

// Allow the Content-Type header
header("Access-Control-Allow-Headers: Content-Type");

// If the request method is OPTIONS, respond with a 200 status code and exit
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$database = "rmi";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Sanitize input data to prevent SQL injection
    $group_name = isset($_GET['group_name']) ? mysqli_real_escape_string($conn, $_GET['group_name']) : '';
    
    // Fetch group_id based on group_name
    $sql_group_id = "SELECT group_id FROM groupchat WHERE group_name = '$group_name'";
    $result_group_id = $conn->query($sql_group_id);

    if ($result_group_id->num_rows > 0) {
        $row_group_id = $result_group_id->fetch_assoc();
        $group_id = $row_group_id['group_id'];

        // Fetch file history based on group_id
        $sql = "SELECT file_name FROM groupmessage WHERE group_id = '$group_id' AND file_name IS NOT NULL"; // Filter out null file names
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $fileHistory = array();
            while ($row = $result->fetch_assoc()) {
                $fileHistory[] = $row; // Append the row directly
            }
            // Return file history as JSON response
            echo json_encode($fileHistory);
        } else {
            // Return empty response if no file history found
            echo json_encode([]);
        }
    } else {
        // Return empty response if no group found with the provided group_name
        echo json_encode([]);
    }
}

// Close connection
$conn->close();
?>
