<?php
// Allow cross-origin requests
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rmi";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables for member ID and group ID
$memberId = null;
$groupId = null;

// Get member ID based on the senderContactNo
$senderContactNo = $_POST['senderContactNo'];
$sqlGetMemberId = "SELECT id FROM users WHERE contact_no = '$senderContactNo'";
$result = $conn->query($sqlGetMemberId);

if ($result->num_rows > 0) {
    // Fetch member ID
    $row = $result->fetch_assoc();
    $memberId = $row["id"];
} else {
    echo "Member not found.";
    $conn->close();
    exit();
}

// Get group ID based on the selectedGroup
$groupName = $_POST['group_name'];
$sqlGetGroupId = "SELECT group_id FROM groupchat WHERE group_name = '$groupName'";
$result = $conn->query($sqlGetGroupId);

if ($result->num_rows > 0) {
    // Fetch group ID
    $row = $result->fetch_assoc();
    $groupId = $row["group_id"];
} else {
    echo "Group not found.";
    $conn->close();
    exit();
}

// Prepare SQL statement to delete member from groupmembers table
$sql = "DELETE FROM groupmembers WHERE members_id = $memberId AND group_id = $groupId";

// Execute the query
if ($conn->query($sql) === TRUE) {
    echo "Member kicked successfully.";
} else {
    echo "Error kicking member: " . $conn->error;
}

// Close connection
$conn->close();
?>
