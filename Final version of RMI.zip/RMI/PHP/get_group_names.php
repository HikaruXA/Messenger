<?php
// Allow requests from the specific origin
header("Access-Control-Allow-Origin: http://localhost:5173");

// Allow the appropriate HTTP methods
header("Access-Control-Allow-Methods: GET");

// Allow the Content-Type header
header("Access-Control-Allow-Headers: Content-Type");

// If the request method is OPTIONS, respond with a 200 status code and exit
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$database = "rmi";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Sanitize input data to prevent SQL injection
    $senderContactNo = isset($_GET['senderContactNo']) ? mysqli_real_escape_string($conn, $_GET['senderContactNo']) : '';
  
    // Fetch group names based on sender contact number
    $sql = "SELECT group_name FROM groupchat WHERE group_id IN 
            (SELECT group_id FROM groupmembers WHERE members_id = 
            (SELECT id FROM users WHERE contact_no = '$senderContactNo'))";
  
    $result = $conn->query($sql);
  
    if ($result->num_rows > 0) {
        $groupNames = array();
        // Fetch each row and add group names to the array
        while ($row = $result->fetch_assoc()) {
            $groupNames[] = $row['group_name'];
        }
        // Encode the array as JSON and output
        echo json_encode($groupNames);
    } else {
        // If no group names found, return an empty array
        echo json_encode([]);
    }
}

// Close connection
$conn->close();
?>
