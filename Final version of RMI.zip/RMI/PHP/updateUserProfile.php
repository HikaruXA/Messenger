<?php
// Allow requests from the specified origin (replace http://localhost:5173 with your frontend URL)
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// If the request method is OPTIONS, respond with CORS headers and exit
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Origin: http://localhost:5173");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Allow-Headers: Content-Type");
    exit;
}

// Process the POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if all required fields are provided
    if (!isset($_POST['userId']) || !isset($_POST['status']) || !isset($_POST['bio'])) {
        echo json_encode(array("error" => "Missing required fields"));
        exit;
    }

    // Retrieve data from POST request
    $userId = $_POST['userId'];
    $status = $_POST['status'];
    $bio = $_POST['bio'];

    // Connect to MySQL database
    $servername = "localhost"; // Replace with your MySQL server name
    $username = "root"; // Replace with your MySQL username
    $db_password = ""; // Replace with your MySQL password
    $dbname = "rmi"; // Replace with your MySQL database name

    try {
        // Set PDO error mode to exception
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $db_password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Update user's status and bio in the database
        $stmt = $conn->prepare("UPDATE userprofile SET status = :status, bio = :bio WHERE user_id = :userId");
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':bio', $bio);
        $stmt->bindParam(':userId', $userId);
        $stmt->execute();

        // Handle profile picture upload
        if (isset($_FILES['profilePicture']) && $_FILES['profilePicture']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = "D:/Xampp/htdocs/RMI/profile_uploads/"; // Replace with your upload directory
            $fileName = basename($_FILES['profilePicture']['name']);
            $uploadPath = $uploadDir . $fileName;
            // Move the uploaded file to the specified directory
            if (move_uploaded_file($_FILES['profilePicture']['tmp_name'], $uploadPath)) {
                // Update profile_name in the database
                $stmt = $conn->prepare("UPDATE userprofile SET profile_name = :profileName WHERE user_id = :userId");
                $stmt->bindParam(':profileName', $fileName);
                $stmt->bindParam(':userId', $userId);
                $stmt->execute();

                echo json_encode(array("success" => "Profile picture uploaded successfully"));
            } else {
                echo json_encode(array("error" => "Failed to upload profile picture"));
            }
        } else {
            echo json_encode(array("error" => "No profile picture provided"));
        }
    } catch(PDOException $e) {
        // Respond with error message
        echo json_encode(array("error" => "Error: " . $e->getMessage()));
    }

    // Close database connection
    $conn = null;
}
?>
