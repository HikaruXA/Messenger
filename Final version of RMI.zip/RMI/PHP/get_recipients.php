<?php
// Allow requests from the specified origin (replace http://localhost:5173 with your frontend URL)
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type");

// If the request method is OPTIONS, respond with CORS headers and exit
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Origin: http://localhost:5173");
    header("Access-Control-Allow-Methods: GET, POST");
    header("Access-Control-Allow-Headers: Content-Type");
    exit;
}

// Connect to MySQL database
$servername = "localhost"; // Replace with your MySQL server name
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$dbname = "rmi"; // Replace with your MySQL database name

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch recipients with their names from the users table
    $stmt = $conn->prepare("SELECT DISTINCT m.receiver_contact_no AS contact_no, u.name FROM messages m JOIN users u ON m.receiver_contact_no = u.contact_no WHERE m.sender_contact_no = :contactNo UNION SELECT DISTINCT m.sender_contact_no AS contact_no, u.name FROM messages m JOIN users u ON m.sender_contact_no = u.contact_no WHERE m.receiver_contact_no = :contactNo");
    $stmt->bindParam(':contactNo', $_GET['senderContactNo']);
    $stmt->execute();
    $recipients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Respond with the list of recipients and their names
    echo json_encode($recipients);
} catch(PDOException $e) {
    // Respond with error message
    echo json_encode(array("error" => "Error: " . $e->getMessage()));
}

// Close database connection
$conn = null;
?>
