<?php
// Database connection parameters
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rmi";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if group_name is provided
if (!isset($_GET['group_name'])) {
  die("Group name not provided.");
}

$groupName = $_GET['group_name'];

// Prepare SQL statement to fetch group members
$sql = "SELECT users.name 
        FROM groupmembers 
        JOIN users ON groupmembers.members_id = users.id 
        WHERE groupmembers.group_id = (
            SELECT group_id 
            FROM groupchat 
            WHERE group_name = '$groupName'
        )";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // Array to hold the members
  $members = array();
  
  // Fetch and output each row
  while($row = $result->fetch_assoc()) {
    $members[] = $row['name'];
  }
  
  // Convert the array to JSON and output
  echo json_encode($members);
} else {
  echo "No members found for this group.";
}

// Close connection
$conn->close();
?>
