<?php
// Allow requests from any origin
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// If the request method is OPTIONS, respond with CORS headers and exit
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Origin: http://localhost:5173");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Allow-Headers: Content-Type");
    exit;
}


// Check if file is uploaded successfully
if ($_FILES['file']['error'] === UPLOAD_ERR_OK) {
    // Get file metadata
    $fileName = $_FILES['file']['name'];
    $fileType = $_FILES['file']['type'];
    $fileSize = $_FILES['file']['size'];
    
    // Read file content
    $fileContent = file_get_contents($_FILES['file']['tmp_name']);
    
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "rmi";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // Prepare SQL statement
    $stmt = $conn->prepare("INSERT INTO files (file_name, file_type, file_size, file_content) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssis", $fileName, $fileType, $fileSize, $fileContent);
    
    // Execute SQL statement
    if ($stmt->execute() === TRUE) {
        echo "File uploaded successfully";
    } else {
        echo "Error uploading file: " . $conn->error;
    }
    
    // Close connection
    $stmt->close();
    $conn->close();
} else {
    echo "Error uploading file";
}
?>
