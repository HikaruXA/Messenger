<?php
// Allow requests from the specified origin (replace http://localhost:5173 with your frontend URL)
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// If the request method is OPTIONS, respond with CORS headers and exit
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Origin: http://localhost:5173");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Allow-Headers: Content-Type");
    exit;
}

// Process the POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $contactNo = $_POST['contactNo'] ?? '';
    $password = $_POST['password'] ?? '';

    // Validate form data (you should implement your validation logic here)

    // Connect to MySQL database
    $servername = "localhost"; // Replace with your MySQL server name
    $username = "root"; // Replace with your MySQL username
    $db_password = ""; // Replace with your MySQL password
    $dbname = "rmi"; // Replace with your MySQL database name

    try {
        // Set PDO error mode to exception
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $db_password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Check user credentials against the database using contactNo
        $stmt = $conn->prepare("SELECT * FROM users WHERE contact_no = :contactNo");
        $stmt->bindParam(':contactNo', $contactNo);
        $stmt->execute();
        
        // Check if the user exists
        if ($stmt->rowCount() > 0) {
            // Fetch user data
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Decrypt the stored password
            $decrypted_password = openssl_decrypt($user['password'], "AES-128-ECB", "1234");

            // Verify password
            if ($password === $decrypted_password) {
                // User authentication successful
                echo json_encode(array("message" => "Login successful"));
            } else {
                // User authentication failed
                echo json_encode(array("error" => "Invalid contact number or password"));
            }
        } else {
            // User not found
            echo json_encode(array("error" => "Invalid contact number or password"));
        }
    } catch(PDOException $e) {
        // Log error
        error_log("Error executing database query: " . $e->getMessage());

        // Respond with error message
        echo json_encode(array("error" => "Error executing database query. Please try again later."));
    }

    // Close database connection
    $conn = null;
}
?>
