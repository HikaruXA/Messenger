<?php
// Allow requests from specific origins
header("Access-Control-Allow-Origin: *");

// Check if it's an OPTIONS request
if ($_SERVER["REQUEST_METHOD"] == "OPTIONS") {
    // Respond with a 200 status code and exit
    http_response_code(200);
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rmi";

try {
    // Create connection
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Handle form submission
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        // Sanitize input data to prevent SQL injection
        $senderContactNo = isset($_GET['senderContactNo']) ? $_GET['senderContactNo'] : '';

        // Fetch user ID based on the provided sender contact number
        $stmt = $conn->prepare("SELECT id FROM users WHERE contact_no = :senderContactNo");
        $stmt->bindParam(':senderContactNo', $senderContactNo, PDO::PARAM_STR);
        $stmt->execute();

        // Fetch user ID
        $userID = $stmt->fetch(PDO::FETCH_ASSOC);

        // Return user ID as JSON response
        echo json_encode($userID);
    }
} catch(PDOException $e) {
    // Return error message
    echo json_encode(array("error" => "Error: " . $e->getMessage()));
}

// Close connection
$conn = null;
?>
