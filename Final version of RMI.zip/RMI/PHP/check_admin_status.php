<?php
// Allow cross-origin requests
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rmi";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if group_name and senderContactNo are provided
if (!isset($_GET['group_name']) || !isset($_GET['senderContactNo'])) {
  die("Group name or sender contact number not provided.");
}

$groupName = $_GET['group_name'];
$senderContactNo = $_GET['senderContactNo'];

// Prepare SQL statement to check admin status
$sql = "SELECT COUNT(*) as isAdmin FROM groupchat WHERE group_name = '$groupName' AND admin_id = (SELECT id FROM users WHERE contact_no = '$senderContactNo')";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  echo json_encode(array('isAdmin' => $row['isAdmin']));
} else {
  echo json_encode(array('isAdmin' => false));
}

// Close connection
$conn->close();
?>
