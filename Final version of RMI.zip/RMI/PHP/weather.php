<?php

header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");

// If the request method is OPTIONS, respond with CORS headers and exit
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Origin: http://localhost:5173");
    header("Access-Control-Allow-Methods: GET");
    header("Access-Control-Allow-Headers: Content-Type");
    exit;
}

// Get the latitude and longitude query parameters from the client-side request
$latitude = $_GET['lat'] ?? '';
$longitude = $_GET['lon'] ?? '';

// If latitude and longitude are provided, fetch weather data from the API
if ($latitude && $longitude) {
    // Construct the URL with latitude, longitude, and API key
    $url = "https://api.openweathermap.org/data/2.5/weather?lat=$latitude&lon=$longitude&appid=e3a664675c79817b3d74921afaa19920";

    // Fetch weather data from the API
    $response = file_get_contents($url);

    // Output the weather data as JSON
    header('Content-Type: application/json');
    echo $response;
} else {
    // Output error message if latitude or longitude parameters are missing
    echo json_encode(['error' => 'Latitude or longitude parameters are missing']);
}
?>
