<?php
// Allow requests from the specific origin
if(isset($_SERVER["HTTP_ORIGIN"]))
{
    // You can decide if the origin in $_SERVER['HTTP_ORIGIN'] is something you want to allow, or as we do here, just allow all
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
}
else
{
    // No HTTP_ORIGIN set, so we allow any. You can disallow if needed here
    header("Access-Control-Allow-Origin: *");
}

header("Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, post, get");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token");
header("Access-Control-Allow-Credentials: true");

// Check if it's an OPTIONS request
if ($_SERVER["REQUEST_METHOD"] == "OPTIONS") {
    // Respond with a 200 status code and exit
    http_response_code(200);
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rmi";

try {
    // Create connection
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Handle form submission
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        // Sanitize input data to prevent SQL injection
        $group_name = isset($_GET['group_name']) ? $_GET['group_name'] : '';
        
        // Fetch the group_id based on the provided group_name
        $stmt_group = $conn->prepare("SELECT group_id FROM groupchat WHERE group_name = :group_name");
        $stmt_group->bindParam(':group_name', $group_name, PDO::PARAM_STR);
        $stmt_group->execute();
        $row_group = $stmt_group->fetch(PDO::FETCH_ASSOC);
        $group_id = $row_group['group_id'];
		
        // Prepare and execute statement to fetch messages along with sender's ID based on the obtained group_id
        $stmt = $conn->prepare("SELECT gm.message, gm.members_id, u.name, u.contact_no AS senderContactNo 
                                FROM groupmessage gm 
                                INNER JOIN users u ON gm.members_id = u.id 
                                WHERE gm.group_id = :group_id");
		
        $stmt->bindParam(':group_id', $group_id, PDO::PARAM_INT);
        $stmt->execute();

        // Fetch all messages and sender IDs
        $chatHistory = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Return chat history as JSON response
        echo json_encode($chatHistory);
    }
} catch(PDOException $e) {
    // Return error message
    echo json_encode(array("error" => "Error: " . $e->getMessage()));
}

// Close connection
$conn = null;
?>
