<?php
// Allow requests from the specific origin
header("Access-Control-Allow-Origin: http://localhost:5173");

// Allow the appropriate HTTP methods
header("Access-Control-Allow-Methods: GET");

// Allow the Content-Type header
header("Access-Control-Allow-Headers: Content-Type");

// If the request method is OPTIONS, respond with a 200 status code and exit
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$database = "rmi";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle file download request
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['filename'])) {
    // Sanitize input data to prevent SQL injection
    $filename = basename($_GET['filename']);
    $filepath = "D:/Xampp/htdocs/RMI/group_uploads/" . $filename;

    // Check if the file exists
    if (file_exists($filepath)) {
        // Set headers for file download
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filepath));
        ob_clean();
        flush();
        // Read the file and output it to the browser
        readfile($filepath);
        exit;
    } else {
        // File not found
        http_response_code(404);
        exit;
    }
}

// Close connection
$conn->close();
?>
