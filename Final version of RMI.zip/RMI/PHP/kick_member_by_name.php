<?php
// Allow cross-origin requests
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rmi";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if group_name, member_name, and senderContactNo are provided
$groupName = $_POST['group_name'];
$memberName = $_POST['member_name'];
$senderContactNo = $_POST['senderContactNo'];

// Get member ID based on the input name
$sqlGetMemberId = "SELECT id FROM users WHERE name = ?";
$stmt = $conn->prepare($sqlGetMemberId);
$stmt->bind_param("s", $memberName);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
  // Fetch member ID
  $row = $result->fetch_assoc();
  $memberId = $row["id"];

  // Delete associated records in the groupmessage table
  $sqlDeleteMessages = "DELETE FROM groupmessage WHERE members_id = ?";
  $stmtDeleteMessages = $conn->prepare($sqlDeleteMessages);
  $stmtDeleteMessages->bind_param("i", $memberId);
  $stmtDeleteMessages->execute();

  // Prepare SQL statement to delete member from groupmembers table
  $sql = "DELETE FROM groupmembers WHERE members_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $memberId);
  if ($stmt->execute()) {
    echo "Member kicked successfully.";
  } else {
    echo "Error kicking member: " . $stmt->error;
  }
} else {
  echo "Member not found.";
}

// Close statements and connection
$stmt->close();
$stmtDeleteMessages->close();
$conn->close();
?>
